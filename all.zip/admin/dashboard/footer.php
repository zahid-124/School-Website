</div><!-- sl-mainpanel -->
<!-- ########## END: MAIN PANEL ########## -->

<script src="/sjr-academy/admin/lib/jquery/jquery.js"></script>
<script src="/sjr-academy/admin/lib/popper.js/popper.js"></script>
<script src="/sjr-academy/admin/lib/bootstrap/bootstrap.js"></script>
<script src="/sjr-academy/admin/lib/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>

<script src="/sjr-academy/admin/js/starlight.js"></script>

</body>
</html>
