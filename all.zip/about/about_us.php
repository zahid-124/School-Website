<?php
require '../dashboard/header.php'
?>
<section class="mt-3 mb-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10">
                <div class="aboutus" style="background-color: white">
                    <div class="bg-primary text-white p-3 mb-2 rounded-3">
                        <h4>About Us</h4>
                    </div>
                    <div class="p-2 text-justify rounded" style="background-color: #F1F8E9;">
                        Jatiya Kabi Kazi Nazrul Islam University was established by the Government of Bangladesh on 09 May 2006, though the initiative for its establishment was taken some years before, firstly by a non-official group of socio-cultural local elites, namely Greater Mymensingh Cultural Forum. The university was originally conceived to be built as the first cultural university in Bangladesh, but the JKKNIU Act enacted in 2006 made it a general university with a special focus on liberal-cum-performing arts education and research.<br><br>
                        Jatiya Kabi Kazi Nazrul Islam University was established by the Government of Bangladesh on 09 May 2006, though the initiative for its establishment was taken some years before, firstly by a non-official group of socio-cultural local elites, namely Greater Mymensingh Cultural Forum. The university was originally conceived to be built as the first cultural university in Bangladesh, but the JKKNIU Act enacted in 2006 made it a general university with a special focus on liberal-cum-performing arts education and research.<br><br>
                        Contact<br>
                        Namapara, Trishal, Mymenshingh.<br>
                        Fax: 02-21-5555<br>
                        Mobile: 0178888888888
                    </div>
                </div>
            </div>
            <div class="col-lg-1"></div>
        </div>
    </div>
</section>
<?php
require '../dashboard/footer.php'
?>